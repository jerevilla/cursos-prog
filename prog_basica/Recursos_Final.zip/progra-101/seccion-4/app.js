let nombre = 'Fernando';
let apellido = 'Herrera';


let nombreCompleto = nombre + ' ' + apellido;

console.log(nombreCompleto);


let a = 10;
let b = 20;

console.log(a + b);


let activo = true;
let despedido = false;