let flores = ['Rosa', 'Girasol', 'Lirio'];




console.log(flores[2]);