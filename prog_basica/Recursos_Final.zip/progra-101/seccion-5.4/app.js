let personas = ['Fernando', 'Melissa', 'Maria'];
let salarios = [1000, 1200, 3000];


for (let i = 0; i < personas.length; i++) {

    console.log(personas[i] + ' tiene un salario de ' + salarios[i]);

}