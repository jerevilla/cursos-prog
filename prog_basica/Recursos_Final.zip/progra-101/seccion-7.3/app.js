let base = 10;
let altura = 5;

let area = (base * altura) / 2;


console.log(area);